Java FPT Console
