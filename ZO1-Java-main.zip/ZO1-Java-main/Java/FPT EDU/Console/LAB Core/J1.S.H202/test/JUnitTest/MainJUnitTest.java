/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUnitTest;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ryuu
 */
public class MainJUnitTest {
    public MainJUnitTest() {
    }
    
    @Test
    public void testprintReverse(){
    }
}
