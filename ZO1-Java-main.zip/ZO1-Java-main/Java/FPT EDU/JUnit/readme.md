JUnit a bit PRJ
