/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author win
 */
public class Main {

    public static void main(String[] args) {
        String str = "Twas brillig and the slithy toves\n"
                + "did gyre and gimble in the wabe.\n"
                + "All mimsey were the borogroves,\n"
                + "and the mome raths outgrabe.\n"
                + "\n"
                + "\"Beware the Jabberwock, my son,\n"
                + "the jaws that bite, the claws that catch,\n"
                + "Beware the JubJub bird and shun\n"
                + "the frumious bandersnatch.\"";
        String result = flipLines(str);
        System.out.println(result);
    }

    private static String flipLines(String str) {
        String lines[] = str.split("\n");
        for (int i = 0; i < lines.length - 1; i += 2) {
            String temp = lines[i];
            lines[i] = lines[i + 1];
            lines[i + 1] = temp;
        }
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }
}
