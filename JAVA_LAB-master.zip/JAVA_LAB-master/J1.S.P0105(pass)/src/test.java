
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author VINH
 */
public class test {

    public static void main(String[] args) throws ParseException {

        // convert into Double

        double d_num = 4;
        System.out.println(Double.valueOf('f') % 1);

    }

}
