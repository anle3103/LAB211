
import Controllers.Options;
import Controllers.Validation;
import java.util.Scanner;
import Views.View;
import java.text.ParseException;

public class Main {

    public static void main(String[] args) throws ParseException {
        View v = new View();
        v.view();
    }
}
