/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solution;

import java.util.Scanner;

/**
 *
 * @author VINH
 */
public class Views {

    public static void main(String[] args) {
        Controllers ctr = new Controllers();
        ctr.printReverse("hello there");
    }
}
